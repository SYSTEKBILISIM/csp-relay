using Bimser.Framework.AspNetCore.Mvc.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Ataven.Helpers.ServiceAPIHelpers;
using Ataven.Managers;
using Ataven.Models;
using System;
using Bimser.Framework.Json;
using Newtonsoft.Json.Linq;
using Bimser.Synergy.Entities.Authentication.Business.DTOs.Requests;

namespace Systek_SynergyCSPRelay.Controllers
{
    [Route("apps/Systek_SynergyCSPRelay/latest/api/Transfer/[action]")]
    [Route("apps/Systek_SynergyCSPRelay/{v:int:min(1)}/api/Transfer/[action]")]
    [Route("api/Transfer/[action]")]
    [Produces("application/json")]
    public class TransferController : Controller
    {
        [HttpGet]
        [ActionName("Ping")]
        [NoRequestHeaders]
        [NoResponseHeaders]
        public string Ping()
        {
            return "TransferController API Controller is ok";
        }

        [HttpPost]
        [ActionName("CreateFlow")]
        [NoRequestHeaders]
        [NoResponseHeaders]
        public async Task<IActionResult> CreateFlow([FromBody] CreateFlowRequestModel request)
        {
            try
            {
                var headers = Request.Headers.ToJsonString().ToObject<JObject>();
                var token = headers["Authorization"][0].ToString().Split(" ")[1];
                var encryptedData = Request.Headers["bimser-encrypted-data"][0].ToString();
                var language = Request.Headers["bimser-language"][0].ToString();
                var serviceAPI = ServiceAPIConnector.Create(token, encryptedData, language);
                if(request.LoginAs != null) {
                    var getUser = serviceAPI.HumanResources.GetUserByUserName(request.LoginAs).Result.Result;
                    var loginAs = serviceAPI.Authentication.LoginAs(new LoginAsRequest(getUser.Id.Value, getUser.Username.Value)).Result.Result;
                }
                var workflowManager = new WorkflowManager(serviceAPI);
                var createFlowResponse = workflowManager.CreateAndSave(request).Result;
                return Ok(createFlowResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPost]
        [ActionName("CreateForm")]
        [NoRequestHeaders]
        [NoResponseHeaders]
        public async Task<IActionResult> CreateForm([FromBody] CreateFormRequestModel request)
        {
            try
            {
                var headers = Request.Headers.ToJsonString().ToObject<JObject>();
                var token = headers["Authorization"][0].ToString().Split(" ")[1];
                var encryptedData = Request.Headers["bimser-encrypted-data"][0].ToString();
                var language = Request.Headers["bimser-language"][0].ToString();
                var serviceAPI = ServiceAPIConnector.Create(token, encryptedData, language);
                if(request.LoginAs != null) {
                    var getUser = serviceAPI.HumanResources.GetUserByUserName(request.LoginAs).Result.Result;
                    var loginAs = serviceAPI.Authentication.LoginAs(new LoginAsRequest(getUser.Id.Value, getUser.Username.Value)).Result.Result;
                    serviceAPI = ServiceAPIConnector.Create(loginAs.Token, encryptedData, language);
                }
                var formManager = new FormManager(serviceAPI);
                var createFormResponse = formManager.CreateAndSave(request).Result;
                return Ok(createFormResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        
        [HttpPost]
        [ActionName("EditForm")]
        [NoRequestHeaders]
        [NoResponseHeaders]
        public async Task<IActionResult> EditForm([FromBody] EditFormRequestModel request)
        {
            try
            {
                var headers = Request.Headers.ToJsonString().ToObject<JObject>();
                var token = headers["Authorization"][0].ToString().Split(" ")[1];
                var encryptedData = Request.Headers["bimser-encrypted-data"][0].ToString();
                var language = Request.Headers["bimser-language"][0].ToString();
                var serviceAPI = ServiceAPIConnector.Create(token, encryptedData, language);
                if(request.LoginAs != null) {
                    var getUser = serviceAPI.HumanResources.GetUserByUserName(request.LoginAs).Result.Result;
                    var loginAs = serviceAPI.Authentication.LoginAs(new LoginAsRequest(getUser.Id.Value, getUser.Username.Value)).Result.Result;
                }
                var formManager = new FormManager(serviceAPI);
                var editFormResponse = formManager.EditAndSave(request).Result;
                return Ok(editFormResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
    }
}